fn main() {
    println!("Hello from ArcForge");
}
