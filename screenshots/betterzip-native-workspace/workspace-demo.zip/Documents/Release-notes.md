# Release notes

- ZIP and ZIP64 browsing
- Text and hexadecimal previews
- Selected or complete extraction
