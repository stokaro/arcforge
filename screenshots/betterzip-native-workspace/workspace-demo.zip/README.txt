ArcForge example archive

An original fixture for interface checks.

Documents contains guides and notes.
Source contains a small Rust example.
Data contains text and binary samples.

No private or third-party files are used.
